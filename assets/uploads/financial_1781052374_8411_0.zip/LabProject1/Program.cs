var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

// CHANGE THIS - HelloApp as default page
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=HelloApp}/{id?}");

app.Run();