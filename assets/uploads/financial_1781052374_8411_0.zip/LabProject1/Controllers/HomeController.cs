using Microsoft.AspNetCore.Mvc;

namespace AllInOneMvcApp.Controllers
{
    public class HomeController : Controller
    {
        // Hello App
        public IActionResult HelloApp()
        {
            return View();
        }

        [HttpPost]
        public IActionResult HelloApp(string message1, string userInput)
        {
            if (!string.IsNullOrEmpty(message1))
            {
                ViewBag.Message1 = message1;
            }

            if (!string.IsNullOrEmpty(userInput))
            {
                ViewBag.Message2 = $"Hello {userInput}!";
            }

            return View();
        }

        // Temperature Converter
        public IActionResult TemperatureConverter()
        {
            return View();
        }

        [HttpPost]
        public IActionResult TemperatureConverter(double celsius)
        {
            ViewBag.Celsius = celsius;
            double fahrenheit = (celsius * 9 / 5) + 32;
            ViewBag.Fahrenheit = fahrenheit.ToString("F1");

            if (celsius >= 36.1 && celsius <= 37.2)
                ViewBag.BodyStatus = "Normal body temperature";
            else if (celsius > 37.2)
                ViewBag.BodyStatus = "Fever - Above normal";
            else
                ViewBag.BodyStatus = "Below normal temperature";

            if (celsius >= 35)
                ViewBag.WeatherStatus = "Very Hot";
            else if (celsius >= 28)
                ViewBag.WeatherStatus = "Hot";
            else if (celsius >= 20)
                ViewBag.WeatherStatus = "Warm";
            else if (celsius >= 10)
                ViewBag.WeatherStatus = "Cool";
            else
                ViewBag.WeatherStatus = "Cold";

            return View();
        }

        // Grade Calculator
        public IActionResult GradeCalculator()
        {
            return View();
        }

        [HttpPost]
        public IActionResult GradeCalculator(string name, double test, double assignment, double project, double finalExam)
        {
            ViewBag.Name = name;
            ViewBag.Test = test;
            ViewBag.Assignment = assignment;
            ViewBag.Project = project;
            ViewBag.FinalExam = finalExam;

            double testWeighted = (test / 25) * 15;
            double assignmentWeighted = (assignment / 50) * 20;
            double projectWeighted = (project / 75) * 25;
            double examWeighted = (finalExam / 100) * 40;

            double overall = testWeighted + assignmentWeighted + projectWeighted + examWeighted;
            ViewBag.OverallMark = overall.ToString("F2");

            string grade = "";
            if (overall >= 80) grade = "A";
            else if (overall >= 75) grade = "A-";
            else if (overall >= 70) grade = "B+";
            else if (overall >= 65) grade = "B";
            else if (overall >= 60) grade = "B-";
            else if (overall >= 55) grade = "C+";
            else if (overall >= 50) grade = "C";
            else if (overall >= 45) grade = "D";
            else grade = "F";

            ViewBag.Grade = grade;
            return View();
        }

        // MCQ App
        public IActionResult MCQApp()
        {
            return View();
        }

        [HttpPost]
        public IActionResult MCQApp(string selectedOption)
        {
            if (selectedOption != null)
            {
                int index = int.Parse(selectedOption);
                string[] options = { "JavaScript", "HTML", "C#", "CSS", "AJAX" };
                string[] values = { "JS", "HTML", "C", "CSS", "AJAX" };

                ViewBag.SelectedIndex = index;
                ViewBag.SelectedItem = options[index];
                ViewBag.SelectedValue = values[index];
            }
            return View();
        }

        // Favourite Pet
        public IActionResult FavouritePet()
        {
            return View();
        }

        // Electricity Bill
        public IActionResult ElectricityBill()
        {
            return View();
        }

        [HttpPost]
        public IActionResult ElectricityBill(string customerName, int currentReading, int previousReading)
        {
            ViewBag.CustomerName = customerName;
            ViewBag.CurrentReading = currentReading;
            ViewBag.PreviousReading = previousReading;

            int unitsUsed = currentReading - previousReading;
            ViewBag.TotalUnits = unitsUsed;

            int block1Units = 0, block2Units = 0, block3Units = 0;
            double block1Amount = 0, block2Amount = 0, block3Amount = 0;

            if (unitsUsed > 0)
            {
                block1Units = (unitsUsed >= 300) ? 300 : unitsUsed;
                block1Amount = block1Units * 0.30;

                if (unitsUsed > 300)
                {
                    int remaining = unitsUsed - 300;
                    block2Units = (remaining >= 400) ? 400 : remaining;
                    block2Amount = block2Units * 0.40;
                }

                if (unitsUsed > 700)
                {
                    block3Units = unitsUsed - 700;
                    block3Amount = block3Units * 0.50;
                }
            }

            ViewBag.Block1Units = block1Units;
            ViewBag.Block2Units = block2Units;
            ViewBag.Block3Units = block3Units;
            ViewBag.Block1Amount = block1Amount.ToString("F2");
            ViewBag.Block2Amount = block2Amount.ToString("F2");
            ViewBag.Block3Amount = block3Amount.ToString("F2");

            double totalAmount = block1Amount + block2Amount + block3Amount;
            ViewBag.TotalAmount = totalAmount.ToString("F2");

            return View();
        }
    }
}